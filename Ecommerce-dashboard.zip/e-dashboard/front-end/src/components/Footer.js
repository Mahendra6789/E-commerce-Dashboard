import React from "react";

const Footer=()=>{
    return(
        <div className="footer">
            <h3>E-comm Dashboard</h3>
        </div>
    )
}

export default Footer;