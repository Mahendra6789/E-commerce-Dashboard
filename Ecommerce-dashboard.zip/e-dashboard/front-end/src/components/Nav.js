import React from "react"
import { Link, useNavigate } from "react-router-dom";

const Nav = () => {
    const auth = localStorage.getItem('user');
    const navigate = useNavigate();
    const logout = () => {
        localStorage.clear();
        navigate('/signup')
    }
    return (
        <div>
            <img  alt="logo"
            className="logo"
            src="https://img.freepik.com/premium-vector/e-commerce-icon-robotic-hand-internet-shopping-online-purchase-add-cart_127544-586.jpg?w=2000"/>
            {
                auth ?
                    <ul className="nav-ul">
                        <li><Link to='/'>Products</Link></li>
                        <li><Link to='/add'>Add Products</Link></li>
                        <li><Link to='/update'>Update Products</Link></li>
                        {/* <li><Link to ='/logout'>logout</Link></li> */}
                        <li><Link to='/profile'>profile</Link></li>
                        <li><Link onClick={logout} to='/signuP'>logout ({JSON.parse(auth).name})</Link></li>
                        {/* // <Link to ='/signuP'>SignUp</Link></li>
             <li><Link to ='/login'>Login</Link></li>
            */}
                    </ul>
                    :
                    <ul className="nav-ul nav-right">
                        <li><Link to='/signuP'>SignUp</Link></li>
                        <li><Link to='/login'>Login</Link></li>
                    </ul>
            }


            {/* auth ? <li><Link onClick={logout}to ='/signuP'>logout</Link></li>
                 :<>
                 <li><Link to ='/signuP'>SignUp</Link></li>
                 <li><Link to ='/login'>Login</Link></li>
                 </>
             */}
        </div>
    )
}

export default Nav;